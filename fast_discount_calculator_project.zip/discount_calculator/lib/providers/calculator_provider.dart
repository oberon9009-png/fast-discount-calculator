import 'package:flutter/foundation.dart';
import '../models/discount_result.dart';

class CalculatorProvider extends ChangeNotifier {
  DiscountResult? _result;
  String? _error;
  DiscountResult? get result => _result;
  String? get error => _error;

  void calculate(String price, String percent) {
    _result = null;
    _error = null;
    if (price.trim().isEmpty || percent.trim().isEmpty) {
      _error = 'أدخل السعر الأصلي ونسبة الخصم حتى نحسب النتيجة.';
    } else {
      final p = double.tryParse(price.trim());
      final d = double.tryParse(percent.trim());
      if (p == null || !p.isFinite || p < 0) {
        _error = 'يرجى إدخال سعر صحيح، ويجب ألا يكون سالباً.';
      } else if (d == null || !d.isFinite) {
        _error = 'يرجى إدخال نسبة خصم صحيحة.';
      } else if (d < 0 || d > 100) {
        _error = 'نسبة الخصم يجب أن تكون بين 0 و100٪.';
      } else {
        _result = DiscountResult.calculate(price, percent);
      }
    }
    notifyListeners();
  }

  void clear() {
    _result = null;
    _error = null;
    notifyListeners();
  }
}
