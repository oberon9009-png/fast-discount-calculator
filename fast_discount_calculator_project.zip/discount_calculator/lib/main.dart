import 'dart:ui';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'models/discount_result.dart';
import 'providers/calculator_provider.dart';

const _bg = Color(0xFF0B1020);
const _surface = Color(0xCC151A2E);
const _purple = Color(0xFF7C4DFF);
const _cyan = Color(0xFF00E5FF);
const _green = Color(0xFF00E676);
const _red = Color(0xFFFF5252);

void main() => runApp(ChangeNotifierProvider(create: (_) => CalculatorProvider(), child: const DiscountApp()));

class DiscountApp extends StatelessWidget {
  const DiscountApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Fast Discount Calculator', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: _bg,
      colorScheme: ColorScheme.fromSeed(seedColor: _purple, brightness: Brightness.dark),
      textTheme: GoogleFonts.tajawalTextTheme(ThemeData.dark().textTheme),
      inputDecorationTheme: const InputDecorationTheme(border: InputBorder.none)),
    home: const Directionality(textDirection: TextDirection.rtl, child: HomeScreen()),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final _priceController = TextEditingController();
  final _discountController = TextEditingController();
  final _priceFocus = FocusNode();
  final _discountFocus = FocusNode();
  late final AnimationController _backgroundController;
  final _numberFormat = NumberFormat('#,##0.00', 'en_US');

  @override
  void initState() {
    super.initState();
    _backgroundController = AnimationController(vsync: this, duration: const Duration(seconds: 12))..repeat();
    _priceController.addListener(_liveCalculate);
    _discountController.addListener(_liveCalculate);
  }
  void _liveCalculate() {
    if (_priceController.text.isNotEmpty && _discountController.text.isNotEmpty) {
      context.read<CalculatorProvider>().calculate(_priceController.text, _discountController.text);
    } else {
      context.read<CalculatorProvider>().clear();
    }
  }
  String _money(double value) => '${_numberFormat.format(value)} د.ع';
  void _calculate() {
    FocusScope.of(context).unfocus();
    HapticFeedback.lightImpact();
    context.read<CalculatorProvider>().calculate(_priceController.text, _discountController.text);
  }
  void _clear() {
    _priceController.clear(); _discountController.clear();
    context.read<CalculatorProvider>().clear();
    FocusScope.of(context).requestFocus(_priceFocus);
  }
  Future<void> _copy(DiscountResult result) async {
    final text = 'السعر بعد الخصم: ${_money(result.finalPrice)}\nالمبلغ الموفّر: ${_money(result.discountAmount)}';
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ النتيجة')));
  }
  @override
  void dispose() {
    _backgroundController.dispose(); _priceController.dispose(); _discountController.dispose();
    _priceFocus.dispose(); _discountFocus.dispose(); super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: AnimatedBuilder(animation: _backgroundController, builder: (context, _) {
      final t = _backgroundController.value;
      return Container(decoration: BoxDecoration(gradient: LinearGradient(
        begin: Alignment(-1 + 2*t, -1), end: Alignment(1 - 2*t, 1),
        colors: const [_bg, Color(0xFF171536), Color(0xFF0C2637), _bg])) ,
        child: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 520),
          child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(22, 28, 22, 28), child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [Container(width: 56, height: 56, decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_purple, _cyan]), borderRadius: BorderRadius.circular(18),
                boxShadow: [BoxShadow(color: _purple.withOpacity(.3), blurRadius: 24)]),
                child: const Icon(Icons.percent_rounded, size: 32, color: Colors.white)),
                const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('حاسبة الخصم', style: GoogleFonts.tajawal(fontSize: 28, fontWeight: FontWeight.w800)),
                  Text('احسب السعر النهائي بثوانٍ', style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 14)),
                ]))]).animate().fadeIn(duration: 500.ms).slideY(begin: -.12),
              const SizedBox(height: 30),
              _GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('تفاصيل السعر', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                const SizedBox(height: 18),
                _InputField(label: 'السعر الأصلي', hint: 'مثلاً 25000', icon: Icons.payments_outlined,
                  controller: _priceController, focusNode: _priceFocus,
                  action: TextInputAction.next, semanticLabel: 'السعر الأصلي', onSubmitted: (_) => _discountFocus.requestFocus()),
                const SizedBox(height: 14),
                _InputField(label: 'نسبة الخصم', hint: 'مثلاً 33', icon: Icons.sell_outlined,
                  controller: _discountController, focusNode: _discountFocus, action: TextInputAction.done,
                  semanticLabel: 'نسبة الخصم بالمئة', suffix: '%', onSubmitted: (_) => _calculate()),
                const SizedBox(height: 20),
                Row(children: [_ActionButton(label: 'احسب الخصم', icon: Icons.calculate_outlined,
                  primary: true, onTap: _calculate), const SizedBox(width: 10),
                  _ActionButton(label: 'مسح', icon: Icons.refresh_rounded, onTap: _clear)]),
              ])).animate().fadeIn(delay: 100.ms, duration: 600.ms).slideY(begin: .08),
              const SizedBox(height: 20),
              Consumer<CalculatorProvider>(builder: (context, provider, _) => AnimatedSwitcher(
                duration: const Duration(milliseconds: 380), switchInCurve: Curves.easeOutBack,
                transitionBuilder: (child, animation) => FadeTransition(opacity: animation,
                  child: SlideTransition(position: Tween<Offset>(begin: const Offset(0, .08), end: Offset.zero).animate(animation),
                    child: ScaleTransition(scale: animation, child: child))),
                child: provider.result != null
                  ? _ResultCard(key: const ValueKey('result'), result: provider.result!, money: _money, onCopy: _copy)
                  : provider.error != null
                    ? _GlassCard(key: const ValueKey('error'), child: Row(children: [const Icon(Icons.info_outline, color: _red), const SizedBox(width: 10), Expanded(child: Text(provider.error!, style: const TextStyle(color: _red)))]))
                    : _GlassCard(key: const ValueKey('waiting'), child: Column(children: [
                        Icon(Icons.auto_awesome_outlined, size: 32, color: _cyan.withOpacity(.9)), const SizedBox(height: 8),
                        const Text('النتيجة تظهر هنا تلقائياً', style: TextStyle(fontSize: 15, color: Colors.white70)),
                        const SizedBox(height: 4), const Text('أدخل السعر ونسبة الخصم للبدء', style: TextStyle(fontSize: 12, color: Colors.white38)),
                      ])),
              )),
              const SizedBox(height: 24),
              Text('تعمل دون إنترنت • العملة: الدينار العراقي', textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white.withOpacity(.38), fontSize: 12)),
            ])))));
    }),
  );
}

class _GlassCard extends StatelessWidget {
  const _GlassCard({required this.child, super.key}); final Widget child;
  @override Widget build(BuildContext context) => ClipRRect(borderRadius: BorderRadius.circular(26), child: BackdropFilter(
    filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16), child: Container(padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(color: _surface, borderRadius: BorderRadius.circular(26),
        border: Border.all(color: Colors.white.withOpacity(.09)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.15), blurRadius: 24, offset: const Offset(0, 10))]), child: child)));
}

class _InputField extends StatefulWidget {
  const _InputField({required this.label, required this.hint, required this.icon, required this.controller,
    required this.focusNode, required this.action, required this.semanticLabel, required this.onSubmitted,
    this.suffix});
  final String label, hint, semanticLabel; final IconData icon; final TextEditingController controller;
  final FocusNode focusNode; final TextInputAction action; final String? suffix;
  final ValueChanged<String> onSubmitted;
  @override State<_InputField> createState() => _InputFieldState();
}
class _InputFieldState extends State<_InputField> {
  bool focused = false;
  @override void initState() { super.initState(); widget.focusNode.addListener(_focusChanged); }
  void _focusChanged() { if (mounted) setState(() => focused = widget.focusNode.hasFocus); }
  @override void dispose() { widget.focusNode.removeListener(_focusChanged); super.dispose(); }
  @override Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(widget.label, style: const TextStyle(fontSize: 14, color: Colors.white70, fontWeight: FontWeight.w600)),
    const SizedBox(height: 8), AnimatedContainer(duration: const Duration(milliseconds: 220), padding: const EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(color: const Color(0xFF0B1020).withOpacity(.72), borderRadius: BorderRadius.circular(17),
        border: Border.all(color: focused ? _cyan : Colors.white.withOpacity(.09), width: focused ? 1.5 : 1),
        boxShadow: focused ? [BoxShadow(color: _cyan.withOpacity(.12), blurRadius: 18)] : []),
      child: Semantics(label: widget.semanticLabel, child: TextField(controller: widget.controller, focusNode: widget.focusNode,
        autofocus: widget.semanticLabel == 'السعر الأصلي', keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: false),
        textInputAction: widget.action, onSubmitted: widget.onSubmitted,
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*'))],
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700), decoration: InputDecoration(
          hintText: widget.hint, hintStyle: const TextStyle(color: Colors.white30, fontWeight: FontWeight.w400),
          prefixIcon: Icon(widget.icon, color: focused ? _cyan : Colors.white38), prefixIconConstraints: const BoxConstraints(minWidth: 38),
          suffixText: widget.suffix, suffixStyle: const TextStyle(color: _cyan, fontSize: 20, fontWeight: FontWeight.w800))))),
  ]);
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({super.key, required this.result, required this.money, required this.onCopy});
  final DiscountResult result; final String Function(double) money; final Future<void> Function(DiscountResult) onCopy;
  @override Widget build(BuildContext context) => _GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    Row(children: [const Icon(Icons.check_circle_rounded, color: _green), const SizedBox(width: 9),
      const Expanded(child: Text('نتيجة الخصم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
      Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: _green.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
        child: Text('${result.discountPercent.toStringAsFixed(result.discountPercent.truncateToDouble() == result.discountPercent ? 0 : 1)}٪ خصم', style: const TextStyle(color: _green, fontWeight: FontWeight.w800)))]),
    const SizedBox(height: 22), const Text('السعر بعد الخصم', style: TextStyle(color: Colors.white60, fontSize: 14)),
    TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: result.finalPrice), duration: const Duration(milliseconds: 650), curve: Curves.easeOutCubic,
      builder: (context, value, _) => FittedBox(alignment: Alignment.centerRight, fit: BoxFit.scaleDown, child: Text(money(value),
        style: const TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: Colors.white)))),
    const SizedBox(height: 18), Container(height: 1, color: Colors.white.withOpacity(.08)), const SizedBox(height: 16),
    Row(children: [const Icon(Icons.savings_outlined, color: _green, size: 22), const SizedBox(width: 8),
      const Expanded(child: Text('المبلغ الموفّر', style: TextStyle(color: Colors.white70))),
      TweenAnimationBuilder<double>(tween: Tween(begin: 0, end: result.discountAmount), duration: const Duration(milliseconds: 650), curve: Curves.easeOutCubic,
        builder: (context, value, _) => Text(money(value), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: _green)))]),
    const SizedBox(height: 20), SizedBox(height: 50, child: FilledButton.icon(onPressed: () => onCopy(result), icon: const Icon(Icons.copy_rounded),
      label: const Text('نسخ النتيجة'), style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))))),
  ]));
}

class _ActionButton extends StatefulWidget {
  const _ActionButton({required this.label, required this.icon, required this.onTap, this.primary = false});
  final String label; final IconData icon; final VoidCallback onTap; final bool primary;
  @override State<_ActionButton> createState() => _ActionButtonState();
}
class _ActionButtonState extends State<_ActionButton> {
  bool pressed = false;
  @override Widget build(BuildContext context) => Expanded(child: GestureDetector(onTapDown: (_) => setState(() => pressed = true),
    onTapCancel: () => setState(() => pressed = false), onTapUp: (_) => setState(() => pressed = false), onTap: () { HapticFeedback.lightImpact(); widget.onTap(); },
    child: AnimatedScale(scale: pressed ? .96 : 1, duration: const Duration(milliseconds: 100), child: Container(height: 52,
      decoration: BoxDecoration(gradient: widget.primary ? const LinearGradient(colors: [_purple, Color(0xFF5B70FF)]) : null,
        color: widget.primary ? null : Colors.white.withOpacity(.06), borderRadius: BorderRadius.circular(16),
        border: Border.all(color: widget.primary ? Colors.transparent : Colors.white.withOpacity(.1))),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(widget.icon, size: 19), const SizedBox(width: 7),
        Flexible(child: Text(widget.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)))])))));
}
