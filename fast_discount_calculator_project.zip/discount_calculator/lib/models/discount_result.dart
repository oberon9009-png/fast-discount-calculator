class DiscountResult {
  const DiscountResult({required this.originalPrice, required this.discountPercent,
    required this.discountAmount, required this.finalPrice});

  final double originalPrice;
  final double discountPercent;
  final double discountAmount;
  final double finalPrice;

  static DiscountResult? calculate(String priceText, String discountText) {
    final price = double.tryParse(priceText.trim());
    final percent = double.tryParse(discountText.trim());
    if (price == null || percent == null || !price.isFinite || !percent.isFinite) return null;
    if (price < 0 || percent < 0 || percent > 100) return null;
    final saved = price * percent / 100;
    return DiscountResult(
      originalPrice: price,
      discountPercent: percent,
      discountAmount: double.parse(saved.toStringAsFixed(2)),
      finalPrice: double.parse((price - saved).toStringAsFixed(2)),
    );
  }
}
