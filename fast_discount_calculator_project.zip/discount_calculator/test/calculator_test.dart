import 'package:flutter_test/flutter_test.dart';
import 'package:fast_discount_calculator/models/discount_result.dart';
import 'package:fast_discount_calculator/providers/calculator_provider.dart';

void main() {
  group('DiscountResult.calculate', () {
    test('100 at 33% gives 67 final and 33 saved', () {
      final result = DiscountResult.calculate('100', '33')!;
      expect(result.finalPrice, 67);
      expect(result.discountAmount, 33);
    });
    test('25000 at 33% gives expected amounts', () {
      final result = DiscountResult.calculate('25000', '33')!;
      expect(result.finalPrice, 16750);
      expect(result.discountAmount, 8250);
    });
    test('zero discount leaves full price', () {
      final result = DiscountResult.calculate('100', '0')!;
      expect(result.finalPrice, 100);
      expect(result.discountAmount, 0);
    });
    test('100% discount leaves zero', () {
      final result = DiscountResult.calculate('100', '100')!;
      expect(result.finalPrice, 0);
      expect(result.discountAmount, 100);
    });
    test('invalid percentage returns null', () {
      expect(DiscountResult.calculate('100', '101'), isNull);
    });
    test('empty input returns null', () {
      expect(DiscountResult.calculate('', '33'), isNull);
    });
  });

  test('provider reports out-of-range percentage', () {
    final provider = CalculatorProvider();
    provider.calculate('100', '101');
    expect(provider.result, isNull);
    expect(provider.error, contains('بين 0 و100'));
  });
}
