import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:fast_discount_calculator/main.dart';
import 'package:fast_discount_calculator/providers/calculator_provider.dart';

void main() {
  testWidgets('price field is available and result updates after inputs', (tester) async {
    await tester.pumpWidget(ChangeNotifierProvider(
      create: (_) => CalculatorProvider(), child: const DiscountApp()));
    await tester.pump(const Duration(milliseconds: 700));
    final fields = find.byType(TextField);
    expect(fields, findsNWidgets(2));
    await tester.enterText(fields.at(0), '25000');
    await tester.enterText(fields.at(1), '33');
    await tester.pump(const Duration(milliseconds: 800));
    expect(find.textContaining('16,750.00'), findsOneWidget);
    expect(find.textContaining('8,250.00'), findsOneWidget);
  });
}
